#include "shell.cpp"

int main(){
    
    Shell shell = Shell();

    shell.start_execution();

    return 0;
}