Here comes the source code for PA1. The following files are included:

-- Ackerman.h and .cpp : These files contain the Ackerman class that is to exercise your allocator. Call the function Ackerman::test() from your Main.cpp.

-- BuddyAllocator.h and .cpp : Contain the Allocator class, where the .cpp has placeholder implementations of the functions defined in the header. This code is operational as-is, but you need to replace the implementation (inside the .cpp) with yours!

-- Main.cpp: This file calls the Ackerman::test() function to exercise your allocator. You will need to add initialization and clean-up of the allocator on exit.

-- makefile : This file tells 'make' how to compile everything together.

